<?php if(!defined('KIRBY')) exit ?>

username: joonas-yliaho-gmail-com
password: >
  $2a$10$6M37RxwzEJZiCcLtlu9jiebk/4L3UJ.HTBFGIDyFyJQGlJuDSUirG
email: joonas.yliaho@gmail.com
language: en
role: admin
history:
  - projects/project-c
  - projects/project-b
  - projects/project-a
  - about/additional-links
  - about
firstname: ""
lastname: ""
