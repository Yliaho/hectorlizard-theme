<?php if(!defined('KIRBY')) exit ?>

username: hectorlizard
firstname: Hector
lastname: Lizard
email: hectorlizard@gmail.com
password: >
  $2a$10$OBGKqbGtumr4UCjZ.8QFcO9ZzCJ.7puYrcETZtt/a90w6A4eHns2e
language: en
role: admin
