<div class="hamburger-menu">
    <a class="hamburger-icon" href="javascript:void(0)" onclick="toggleMobileNav()"></a>
</div>    