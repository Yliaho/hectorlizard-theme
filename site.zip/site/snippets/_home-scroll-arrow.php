<div class="scroll-cta">
    <a href="#main" class="scroll-arrow" onclick="arrowOnClick()"><svg id="hero-scroll-arrow" xmlns="http://www.w3.org/2000/svg" width="31" height="17" viewBox="0 0 31 17"><g style="fill:none;stroke-linejoin:bevel"><g stroke="#000"><path d="M15.8 15.9L15.9 16 30.6 1.3 30.3 1 15.8 15.5 1.3 1 1 1.3 15.7 16 15.8 15.9Z"/></g></g></svg></a>
</div>