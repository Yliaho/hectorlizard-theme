<footer class="footer" role="contentinfo">
    <div class="landing-bottom-container hidden-sm-down">
        <?php snippet('_home-navigation') ?>
        <?php snippet('_home-social') ?>
    </div>
  </footer>
  <?php echo js('assets/js/jquery-3.2.1.min.js') ?>
  <?php echo js('assets/js/script_min.js') ?>
</body>
</html>