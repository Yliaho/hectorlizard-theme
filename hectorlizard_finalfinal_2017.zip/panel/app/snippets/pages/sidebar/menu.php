<h2 class="hgroup hgroup-single-line hgroup-compressed cf">
  <span class="hgroup-title">
    <?php _l('pages.show.settings') ?>
  </span>
</h2>

<?php echo $menu ?>
